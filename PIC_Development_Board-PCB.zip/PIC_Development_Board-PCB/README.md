# PIC Development Board - PCB

A PIC16F877A development board designed in EasyEDA by **Indiranandan (ARC)**.

- Revision: 1.0
- Schematic date: 2026-01-18
- Tool: EasyEDA

## Features

- **MCU:** PIC16F877A (40-pin DIP) with reset switch and crystal (X1)
- **Power:** DC jack (DC-047B-13A), 1N4007 protection diode, 5 V regulation (U6 / LM1084T-5.0), power LED
- **RS232:** MAX232 level shifter with DB9 female connector
- **USB:** USB Type-C (KH-TYPE-C-6P) connector
- **Inputs:** 8 push buttons (KEY1-KEY8) plus reset button (KEY9)
- **Outputs:** 8 LEDs on PORTD with 470 ohm current-limiting resistors
- **Analog to digital converter section:** 4 trimmer potentiometers (RP1-RP4) with DIP switch (SW1) channel select
- **Headers:** Full I/O breakout for PORTA, PORTB, PORTC, PORTD, PORTE and power

## Repository Contents

```
PIC_Development_Board-PCB/
├── README.md
├── images/
│   ├── pcb_3d_view.jpeg      3D render of the board
│   ├── schematic.jpeg        Schematic (Sheet_1)
│   └── pcb_layout.jpeg       2D PCB layout
```

## Preview

![3D View](images/pcb_3d_view.jpeg)

![Schematic](images/schematic.jpeg)

![PCB Layout](images/pcb_layout.jpeg)

## Author

Indiranandan - ARC
