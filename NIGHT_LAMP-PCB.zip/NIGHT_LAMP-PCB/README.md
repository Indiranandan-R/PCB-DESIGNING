# NIGHT_LAMP - PCB

An LDR-based automatic lamp circuit using an LM358 op-amp as a comparator, designed in EasyEDA by **indiranandanr**.

- Revision: 1.0
- Schematic date: 2025-12-21
- Tool: EasyEDA
- Supply: 9 V to 12 V DC

## Circuit Overview

| Ref | Part | Value / Type | Function |
|-----|------|--------------|----------|
| U1 | LM358GN | DIP-8 dual op-amp | Comparator |
| U2 | Resistor | 10 kΩ | Upper leg of the light-sensing divider |
| R3 | 02-LDR12 | Light dependent resistor | Light sensor |
| R2 | Potentiometer | 10 kΩ | Threshold (sensitivity) adjust |
| R1 | Resistor | 1 kΩ | Transistor base resistor |
| Q1 | BC547 | NPN transistor | LED driver |
| LED1-LED3 | LED-TH-3mm_G | 3 mm green LEDs | Lamp output (in series) |

## How It Works

The 10 kΩ resistor and the LDR form a voltage divider whose midpoint feeds the inverting input (pin 2) of the LM358. The potentiometer wiper feeds the non-inverting input (pin 3) and sets the switching threshold. The comparator output drives the BC547 through the 1 kΩ resistor, and the transistor switches the three series LEDs.

## Repository Contents

```
NIGHT_LAMP-PCB/
├── README.md
└── images/
    ├── schematic.png          Schematic (Sheet_1)
    ├── pcb_layout_top.png     PCB layout with silkscreen
    ├── pcb_layout_copper.png  PCB layout, copper view
    └── pcb_3d_view.png        3D render of the board
```

## Preview

### Schematic
![Schematic](images/schematic.png)

### PCB Layout
![PCB layout](images/pcb_layout_top.png)

![PCB layout copper](images/pcb_layout_copper.png)

### 3D View
![3D view](images/pcb_3d_view.png)

## Author

indiranandanr
